package info.androidhive.jsonparsing;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductList extends AppCompatActivity {

    String pro_name, pro_detail_json;
    ArrayList<HashMap<String, String>> contactList, contactList2;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        contactList = new ArrayList<>();
        lv = (ListView) findViewById(R.id.product_list);
        pro_name = getIntent().getStringExtra("ProductsName");
        pro_detail_json = getIntent().getStringExtra("Products");

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String ss = contactList.get(position).get("variants");
                variants(ss);
            }
        });
        DeatilsList();
    }


    public void DeatilsList()
    {
        try {
            JSONArray contacts = new JSONArray(pro_detail_json);
            for (int i = 0; i < contacts.length(); i++) {
                JSONObject c = contacts.getJSONObject(i);

                String id = c.getString("id");
                String name = c.getString("name");
                String variants = c.getString("variants");

                Log.d("id",id);
                Log.d("name",name);
                Log.d("variants",variants);

                HashMap<String, String> contact = new HashMap<>();
                // adding each child node to HashMap key => value
                contact.put("name", name);
                contact.put("variants", variants);

                contactList.add(contact);
            }

        } catch (final JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(
                ProductList.this, contactList,
                R.layout.list_item, new String[]{"name"}, new int[]{R.id.product_name});

        lv.setAdapter(adapter);

    }


    public void variants(String ver){
        contactList2 = new ArrayList<>();
        AlertDialog.Builder ad = new AlertDialog.Builder(ProductList.this);
        View v = getLayoutInflater().inflate(R.layout.alert, null);
        ad.setView(v);
        ad.show();
        ListView lvd = (ListView)v.findViewById(R.id.list);
        try {


            JSONArray contacts = new JSONArray(ver);
            for (int i = 0; i < contacts.length(); i++) {
                JSONObject c = contacts.getJSONObject(i);

                String color = c.getString("color");
                String size = c.getString("size");
                String price = c.getString("price");

                HashMap<String, String> contact = new HashMap<>();
                // adding each child node to HashMap key => value
                contact.put("color", color);
                contact.put("size", size);
                contact.put("price", price);

                contactList2.add(contact);
            }

        } catch (final JSONException e) {
            e.printStackTrace();
        }
        ListAdapter adapter = new SimpleAdapter(
                ProductList.this, contactList2,
                R.layout.varity_layout, new String[]{"color","size","price"}, new int[]{R.id.color, R.id.size, R.id.price});

        lvd.setAdapter(adapter);
    }
}
